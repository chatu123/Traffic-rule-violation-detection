from django.db import models
import os
from twilio.rest import Client

class data(models.Model):
    penalty_person=models.CharField(max_length=30 ,null=True)
    challan_no=models.IntegerField(unique=True, null=True)
    vehicle_no=models.CharField(unique=True, max_length=20, null=True)
    violation=models.CharField(max_length=20 ,null=True)
    compensation_fine=models.IntegerField(null=True)


    def __str__(self):
        return '%s %s %s %s %s' %(self.penalty_person, self.challan_no, self.vehicle_no, self.violation, self.compensation_fine)
    
    def save(self,*args, **kwargs):
        if self.compensation_fine > 0 :
            account_sid = 'AC610b70f1c6c934ca694dafc69c243856'
            auth_token = '8632b48a9638af899c64fef8c39e5b06'
            client = Client(account_sid, auth_token)

            message = client.messages.create(
                              body= f'{self.penalty_person} your Challan no {self.challan_no} for {self.vehicle_no} violation of {self.violation} having total compensation fees as Rs.{self.compensation_fine} pay at rto office regards,RTO ',
                              from_='+18124122491',
                              to='+917744854475'
                          )

            print(message.sid)
        return super().save(*args, **kwargs)

